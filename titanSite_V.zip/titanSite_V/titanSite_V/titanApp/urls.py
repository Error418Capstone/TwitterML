#!/usr/local/bin/python3.6
from django.urls import path
from django.views.decorators.csrf import csrf_exempt

from . import views
from .views import menu

urlpatterns = [
    path('', views.home, name='home'),
    path('menu', views.menu, name='menu'),
    path('annotate', views.annotate, name='annotate'),
    path('begin_list', csrf_exempt(views.begin_list), name='begin_list'),
    path('send_data', csrf_exempt(views.send_data), name='send_data'),
    path('annotate_list', csrf_exempt(views.annotate_list), name='annotate_list'),
    path('listClicked', csrf_exempt(views.listClicked), name='listClicked'),
    path('projectClicked', csrf_exempt(views.projectClicked), name='projectClicked'),
    path('getListsToAnnotate', csrf_exempt(views.getListsToAnnotate), name='getListsToAnnotate'),
    path('getProjects', csrf_exempt(views.getProjects), name='getProjects'),

    path('krippmaker', csrf_exempt(views.krippmaker), name = 'krippmaker'),
    path('cohenmaker', csrf_exempt(views.cohenmaker), name = 'cohenmaker'),
    path('predictor', csrf_exempt(views.predictor), name = 'predictor'),
    path('predict', csrf_exempt(views.predict), name = 'predict'),
    path('tweetremover', csrf_exempt(views.tweetremover), name = 'tweetremover'),
    path('model_train', csrf_exempt(views.model_train), name = 'model_train'),
    path('tweetcollector', csrf_exempt(views.tweetcollector), name='tweetcollector'),
    path('collect_tweets', csrf_exempt(views.collect_tweets), name='collect_tweets'),
    path('remove_tweets', csrf_exempt(views.remove_tweets), name='remove_tweets'),
    path('train_model', csrf_exempt(views.train_model), name='train_model'),
    path('cohen_kappa_score', csrf_exempt(views.cohen_kappa_score), name='cohen_kappa_score'),
    path('krippendorff_fleiss_score', csrf_exempt(views.krippendorff_fleiss_score), name = 'krippendorff_fleiss_score'),

    path('about/', views.about, name='titanApp-about'), #added
    path('fetch_tweets/', views.fetch_tweets, name ='titanApp-fetch_tweets'),
    path('ml_params/', views.ml_params, name = 'titanApp-ml_params'),
    path('IAA/', views.IAA, name = 'titanApp-IAA'),

]
