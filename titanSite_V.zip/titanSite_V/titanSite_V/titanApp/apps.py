from django.apps import AppConfig


class TitanappConfig(AppConfig):
    name = 'titanApp'
