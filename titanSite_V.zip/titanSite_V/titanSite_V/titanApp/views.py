#!/usr/local/bin/python3.6
from django.shortcuts import render, redirect
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
import simplejson as json

from django.views.generic import View

from django.http import HttpResponse, HttpResponseRedirect

from .models import Tweet, ListToAnnotate, AnnotationPiece, AnnotatorUser, AnnotationBundle, AnnotationLabel, AnnotationProject, AnnotationAttempt

from django.views.generic import (
    ListView,
    DetailView,
    CreateView,
    UpdateView,
    DeleteView
)

#ml imports
import random
from pathlib import Path

import spacy
from spacy.util import minibatch, compounding
from spacy.lang.en.stop_words import STOP_WORDS

import pandas as pd

from sklearn.metrics import cohen_kappa_score
from statsmodels.stats.inter_rater import fleiss_kappa
import krippendorff

from collections import Counter, defaultdict

#IAA imports
import numpy as np

#Fetch Tweets import
import json
import datetime
import twitter

from titanApp.secret import KEY, SECRET, ACCESS_TOKEN, ACCESS_TOKEN_SECRET



def about(request):
    return render(request, 'titanApp/about.html', {'title': 'about'}) #added




def createDBRecoveryList():

    labelsToDisplay = Tweet.objects.all()

    for label in labelsToDisplay:
        print(label)


    labelsToDisplay = AnnotationLabel.objects.all()

    for label in labelsToDisplay:
        print(label)


tweetsRecoveryList = [['Sky News', 'All London primary schools to remain closed for start of term in government U-turn', 'https://twitter.com/SkyNews/status/1345077352582311936'],['The Associated Press', 'Ravers at banned New Year’s Eve party in France attack police sent to shut event down, torching one of their vehicles and injuring officers with bottles and stones.', 'https://twitter.com/AP/status/1345088152147550217'],['The Independent', 'Dick Thornburgh, Pennsylvania governor during Three Mile Island crisis, dies at 88', 'https://twitter.com/Independent/status/1345087053898383361'],['Bernie Sanders', 'Amazon made $10.8 billion in profits, didnt pay a dime in federal taxes, and got a $129 million check from the IRS—courtesy of Mitch McConnell and the Republican Senate.  But as our people suffer, a', 'https://twitter.com/SenSanders/status/1345078001113948161'],['Al Jazeera English', 'Oman looks to borrow $4.2bn in 2021 to cover budget shortfall https://aje.io/7b452', 'https://twitter.com/AJEnglish/status/1345071074757767170'], ['CNBC', 'Zooms Eric Yuan became one of the worlds richest people as Covid made people rush to meet on video', 'https://twitter.com/CNBC/status/1345084817914949634'], ['Time', '"Of all days in the year, the slaves dread New Years Day the worst of any," one 1842 account explained. Heres why', 'https://twitter.com/TIME/status/1345082791466303490'], ['BBC News (World)', 'Afghanistan violence: Bismillah Aimaq is fifth journalist to die', 'https://twitter.com/BBCWorld/status/1345071048644059138'], ['BBC', 'US Congress overrides Trumps veto of a defence spending bill, the first time this has happened in his presidency', 'https://twitter.com/BBCWorld/status/1345095379650539520'],['Harvard', 'Happy New Year!   Party popper   #NewYear2021', 'https://twitter.com/Harvard/status/1345008203432665089/photo/1'], ['Harvard', 'Hope to see more of you in 2021!', 'https://twitter.com/Harvard/status/1344711185200001025'], ['Harvard', 'More of 2020 at Harvard: 1. A @HarvardDivinity  student in the fall  2. The 2020-21 @HarvardGSAS  RAs in the fall 3. An undergraduate student voted early at Fenway Park 4. @hseas s Science and Engine', 'https://twitter.com/Harvard/status/1344298502017449984'], ['Harvard', '2020 at Harvard: 1. At the beginning of the year, local artist Silvia Lopez Chavez designed and installed a custom mural at @Kennedy_School   2. In the spring, @HarvardHBS  was in full bloom  3. Summe', 'https://twitter.com/Harvard/status/1344297675584393217'], ['Harvard', 'How do we make donation decisions? Harvard psychologists offer insights.', 'https://twitter.com/Harvard/status/1343657980403843074'], ['Harvard', 'Studies say that 8 in 10 Americans experience stress in their daily lives. Of the many offerings aimed at fighting stress, from exercise to yoga to meditation, mindfulness meditation has become increa', 'https://twitter.com/Harvard/status/1343270431483195394'], ['Yale', 'For the latest Yale University guidance and messages related to coronavirus, please visit: http://yale.edu/covid19  #COVID19 #Yale', 'https://twitter.com/Yale/status/1276643941320884230'], ['Yale', 'Wishing you a happy New Year and all the best in 2021!', 'https://twitter.com/Yale/status/1344871244370477057'], ['Yale', '“In addition to academic skills, we need to teach students how to live a balanced life.”  — Emma Seppälä, @YaleEmotion , on a study published in July 2020', 'https://twitter.com/Yale/status/1344726521366392832'], ['Yale', 'In early 2020, Yale pharmacologist Yung-Chi Cheng, a leader in drug development for hepatitis B, cancer, & HIV, launched a trial for a radical idea:  What if he could unlock the therapeutic potential', 'https://twitter.com/Yale/status/1344614539229360130'], ['Yale', 'In October 2020, Yale researchers published first large-scale study of its kind, finding child care workers were not at greater risk of #COVID19  They cautioned results may not apply to settings w/ ol', 'https://twitter.com/Yale/status/1344014082886742018'], ['Yale', 'In summer 2020, new faculty members Elizabeth Hinton and Phillip Atiba Goff joined a growing group of scholars at Yale working on issues related to racial injustice, policing, and mass incarceration.', 'https://twitter.com/Yale/status/1343890766654005248'], ['Yale', 'What killed the dinosaurs? A Yale study published in January 2020 found an asteroid — not volcanic activity — played a direct role in the extinction event.', 'https://twitter.com/Yale/status/1343527872561111041'], ['Brown University', 'Happy New Year to Brunonians near and far! Wishing all members of the Brown community a safe, healthy and happy 2021!', 'https://twitter.com/BrownUniversity/status/1345022467975340040'],['Brown University', 'Happy New Year to Brunonians near and far! Wishing all members of the Brown community a safe, healthy and happy 2021!', 'https://twitter.com/BrownUniversity/status/1345022467975340040']]


labelsRecoveryList = [['None'], ['Opinion'], ['Announcement'], ['Personal Tweet'], ['News Tweet'], ['Anti-Brexit'], ['Pro-Brexit'], ['Labour Party'], ['Tory Party'], ['Neo-Conservative'], ['neoliberal'], ['Far-Left'], ['Alt-Right'],['Progressive'],['Democrat'],['Republican']]

def reuploadDatabase():

    global tweetsRecoveryList

    for tweet in tweetsRecoveryList:
        annotation = Tweet(Publisher = tweet[0], Text = tweet[1], URL = tweet[2])
        annotation.save()

        print("just added this : "+str(annotation))






    global labelsRecoveryList

    for tweet in labelsRecoveryList:
        annotation = AnnotationLabel(LabelText = tweet[0])
        annotation.save()



def saveAnnotation(tweet, annotationData, user, holderList):

    annotation = AnnotationBundle(Tweet = tweet, User = user, forList = holderList)
    annotation.save()

    for annotationPart in annotationData:
        annotation.AnnotationsList.add(annotationPart)

    try:
        print("Adding to a new annotation attempt")
        annotationAttemptObject = AnnotationAttempt.objects.get(AnnotationList=holderList, User=user)

        annotationAttemptObject.ContainsAnnotationBundles.add(annotation)

    except:
        print("Creating a new annotation attempt")
        annotationAttemptObject = AnnotationAttempt(AnnotationList = holderList, User=user)
        annotationAttemptObject.save()

        annotationAttemptObject.ContainsAnnotationBundles.add(annotation)

    print("annotation : "+str(annotation))





def begin_list(request):

    print("begin_list")
    # Extracting request data
    annotateName = str(request.POST.get('listToAnnotate'))
    userName = str(request.POST.get('user'))

    print("annotateName : "+str(annotateName))
    toAnnotate = ListToAnnotate.objects.get(Name=annotateName)
    userObject = AnnotatorUser.objects.get(Name=userName)


    labelsToDisplay = toAnnotate.Labels.all()
    labelsText = []
    showAnnotations = []
    for label in labelsToDisplay:
        labelsText.append(label.LabelText)
        showAnnotations.append(0)

    tweetList = list(toAnnotate.ContainsTweets.all())

    try:
        # If annotation attempt exists, go to latest one
        annotationAttempt = AnnotationAttempt.objects.get(AnnotationList=toAnnotate, User=userObject)

        bundlesDone = list(annotationAttempt.ContainsAnnotationBundles.all())

        finishedTweets = []
        allTweets = []

        for bundle in bundlesDone:
            finishedTweets.append(bundle.Tweet)


        chosenIndex = 0

        for x in range(0, len(tweetList) -1):
            tweet = tweetList[x]

            if tweet not in finishedTweets:
                chosenIndex = x + 1
                break

        returnTweet = tweetList[chosenIndex]

        if len(bundlesDone) == len(tweetList):

            bundle = bundlesDone[0]

            chosenIndex = 0
            returnTweet = tweetList[0]

            bundleAnnotationsList = list(bundle.AnnotationsList.all())

            showAnnotations = []

            for annotation in bundleAnnotationsList:
                if annotation.Input == True:
                    showAnnotations.append(1)
                else:
                    showAnnotations.append(0)

            tweetsAnnotations.append(binaryList)


    except:
        # If no annotation attempt exists, just take the first item in the list.
        chosenIndex = 0                                                                         # CHANGE ZERO TO A ONE!
        returnTweet = tweetList[0]


    data = {"Publisher":returnTweet.Publisher, "Text":returnTweet.Text, "Labels": labelsText, "index": chosenIndex, "length":len(tweetList), "outputList": showAnnotations}

    returner = HttpResponse(json.dumps(data), content_type="application/json")

    return returner





def annotate(request, list_name):
    list_name = str(request.POST.get('title', None))
    return render(request, 'titanApp/home.html', {'data':list_name})




def listClicked(request):
    print("TITLE CLICKED")



    list_name = str(request.POST.get('title', None))
    print("list_name : "+str(list_name))

    title ={'title':list_name}

    return HttpResponse(json.dumps(title), content_type="application/json")



def projectClicked(request):

    list_name = str(request.POST.get('title', None))
    print("list_name : "+str(list_name))

    title ={'title':list_name}

    return HttpResponse(json.dumps(title), content_type="application/json")



def getProjects(request):

    print(" ")
    print("############################################################################")
    print(" ")

    #createDBRecoveryList()
    #reuploadDatabase()


    print(" ")
    print("############################################################################")
    print(" ")



    username = str(request.POST.get('user', None))

    print("username : "+str(username))

    userObject = AnnotatorUser.objects.get(Name=username)

    availableProjects = userObject.AvailableProjects.all()

    projectNames = []

    for project in availableProjects:
        projectNames.append(project.Name)

    data = {"outputList":projectNames}

    returner = HttpResponse(json.dumps(data), content_type="application/json")

    return returner


def getListsToAnnotate(request):

    projectTitle = str(request.POST.get('title', None))

    projectObject = AnnotationProject.objects.get(Name=projectTitle)

    allProjectLists = projectObject.ContainsListsToAnnotate.all()

    username = str(request.POST.get('user', None))
    print("username : "+str(username))

    userObject = AnnotatorUser.objects.get(Name=username)

    listNames = []
    listBundles = []
    listLength = []

    availableLists = userObject.AvailableLists.all()

    for list in allProjectLists:
        if list in availableLists:
            listNames.append(list.Name)

            try:
                existingAttempt = AnnotationAttempt.objects.get(AnnotationList = list, User=userObject)
                listBundles.append(len(existingAttempt.ContainsAnnotationBundles.all()))

            except:

                listBundles.append(0)

            listLength.append(len(list.ContainsTweets.all()))

    data = {"listNames":listNames, "listBundles": listBundles,  "listLength":listLength, "projectTitle": projectTitle}

    returner = HttpResponse(json.dumps(data), content_type="application/json")

    return returner


def menu(request):
    print("MENU")
    global output

    print("----------------------------------------------------       request : "+str(request))


    return render(request, 'titanApp/menu.html')







def annotate_list(request):
    print("ANNOTATE LIST")

    # Fetching all the user inputs


    print(" ")
    print(" ")
    print(" ")
    print(" ")

    print("###################################################################")
    print("###################################################################")
    print("###################################################################")


    indexNumber = int(request.POST.get('index', None))
    labelsList = eval(str("["+request.POST.get('labelsList', None)+"]"))
    username = str(request.POST.get('user', None))
    annotateName = str(request.POST.get('annotateName', None))
    action = str(request.POST.get('action', None))

    print("labelsList : "+str(labelsList))

    #Creating the actual djangoDB objects out of the string inputs

    model = ListToAnnotate
    userObject = AnnotatorUser.objects.get(Name=username)
    toAnnotate = ListToAnnotate.objects.get(Name=annotateName)
    labelsToDisplay = toAnnotate.Labels.all()
    allTweets = list(toAnnotate.ContainsTweets.all())



    # Creating a list of all the labels used in the list
    labelsText = []
    for label in labelsToDisplay:
        labelsText.append(label.LabelText)


    ########################################################################
    #   SAVING THE TWEET WE ARE LEAVING
    ########################################################################

    print(" ")
    print(" ")
    print('----------------------------------------------------------')
    print("SAVING THE TWEET WE ARE LEAVING")
    # Finding if an existing annotationAttempt exists for this element.

    currentTweet = allTweets[indexNumber - 1]

    try:
        # If you can find an existing object, just modify it, and save it.


        existingAnnotationAttempt = AnnotationAttempt.objects.get(AnnotationList=toAnnotate, User=userObject)
        print("Found exisitng annotation attempt : "+str(existingAnnotationAttempt))

        containsAnnotationBundles = list(existingAnnotationAttempt.ContainsAnnotationBundles.all())

        #print("Found these annotation bundles inside : "+str(containsAnnotationBundles))


        found = False

        for bundle in containsAnnotationBundles:
            if bundle.Tweet == currentTweet:


                # Building the list we want to replace it with :

                replacementList = []
                index = 0
                for label in labelsToDisplay:

                    boolean = False
                    if labelsList[index] == 1:
                        boolean = True

                    newAnnotation = AnnotationPiece(Label= label.LabelText, Input=boolean)
                    newAnnotation.save()
                    replacementList.append(newAnnotation)
                    index += 1

                print(" ")
                print("Finished collecting the repalcements")
                print(" ")

                # Clearing the exisitng list to build a new one
                print("bundle : "+str(bundle))
                allAnnotationPieces = list(bundle.AnnotationsList.all())
                print("allAnnotationPieces : "+str(allAnnotationPieces))

                for annotation in allAnnotationPieces:
                    annotation.delete()

                print(" ")
                print("Finished deleting everything")

                # Buidling the new one list
                for replacement in replacementList:
                    print("replacement : "+str(replacement))
                    bundle.AnnotationsList.add(replacement)
                    newAnnotation.save()
                    print("adding")

                found = True

                print("BUNDLE : "+str(bundle.AnnotationsList.all()))

                break


        if found == False:
            raise Exception("We didn't find the bundle in the annotationList bundles")



    except:
        # If you can't find an annotationBundle, then create a new one.
        print(" ")
        print("Except section : we couldn't find an existing annotation bundle, so lets save a new one.")

        listOfAnnotationPieces = []

        index = 0
        for label in labelsToDisplay:

            boolean = False
            if labelsList[index] == 1:
                boolean = True

            newAnnotation = AnnotationPiece(Label= label.LabelText, Input=boolean)
            newAnnotation.save()
            listOfAnnotationPieces.append(newAnnotation)
            index += 1

        saveAnnotation(currentTweet, listOfAnnotationPieces, userObject, toAnnotate)

        print("Could not find an existing list, thus creating a new list.")



    ########################################################################
    #   LOADING THE NEXT TWEET
    ########################################################################

    print(" ")
    print(" ")
    print('----------------------------------------------------------')
    print("LOADING THE NEXT TWEET")

    print(" ")
    print("indexNumber : "+str(indexNumber))

    print(" action "+str(action))
    if action == "next":
        if indexNumber < len(allTweets):
            indexNumber += 1
            nextTweet = allTweets[indexNumber - 1]
    else:
        if indexNumber > 0:
            indexNumber -= 1
            nextTweet = allTweets[indexNumber - 1]



    if indexNumber >= len(allTweets):

        existingAnnotationAttempt = AnnotationAttempt.objects.get(AnnotationList=toAnnotate, User=userObject)
        containsAnnotationBundles = list(existingAnnotationAttempt.ContainsAnnotationBundles.all())

        showAnnotations = []
        found = False

        tweetsPublishers = []
        tweetsTexts = []
        tweetsAnnotations = []

        # Checking if we can find the exisitng tweet
        for bundle in containsAnnotationBundles:
            tweet = bundle.Tweet

            tweetsPublishers.append(tweet.Publisher)
            tweetsTexts.append(tweet.Text)

            smallAnnotations = []

            bundleAnnotationsList = list(bundle.AnnotationsList.all())

            binaryList = []

            for annotation in bundleAnnotationsList:
                if annotation.Input == True:
                    binaryList.append(1)
                else:
                    binaryList.append(0)

            tweetsAnnotations.append(binaryList)

        print("tweetsPublishers : "+str(tweetsPublishers))
        print("tweetsTexts : "+str(tweetsTexts))
        print("tweetsPublishers : "+str(tweetsAnnotations))

        data = {"endList":True, "TweetsPublishers": tweetsPublishers, "TweetsTexts":tweetsTexts , "Labels": labelsText, "TweetsAnnotations": tweetsAnnotations}

        returner = HttpResponse(json.dumps(data), content_type="application/json")
        return returner

    else:

        try:
            # If you can find an existing object, then display the exisiting data
            existingAnnotationAttempt = AnnotationAttempt.objects.get(AnnotationList=toAnnotate, User=userObject)
            containsAnnotationBundles = list(existingAnnotationAttempt.ContainsAnnotationBundles.all())

            showAnnotations = []
            found = False

            # Checking if we can find the exisitng tweet
            for bundle in containsAnnotationBundles:

                print(" ")
                if bundle.Tweet == nextTweet:
                    print("Found a match")

                    itemsAnnotations = list(bundle.AnnotationsList.all())


                    print("Found annotations : "+str(itemsAnnotations))

                    for annotation in itemsAnnotations:
                        print("annotation : "+str(annotation))
                        if annotation.Input == True:
                            showAnnotations.append(1)
                        else:
                            showAnnotations.append(0)


                    print(" ")
                    print("showAnnotations : "+str(showAnnotations))

                    found = True

                    data = {"Publisher":nextTweet.Publisher, "Text":nextTweet.Text, "Labels": labelsText, "endList":False, "index": indexNumber, "length":len(allTweets), "outputList": showAnnotations}

                    returner = HttpResponse(json.dumps(data), content_type="application/json")
                    return returner


            if found == False:
                raise Exception("We didn't find the bundle in the annotationList bundles")

        except:
            # If you can't find an exisitng object, just display a virgin page.

            print("can't find an exisitng object, so I'm creating a fresh page")

            showAnnotations = []
            for label in labelsToDisplay:
                showAnnotations.append(0)

            print("showAnnotations : "+str(showAnnotations))

            data = {"Publisher":nextTweet.Publisher, "Text":nextTweet.Text, "Labels": labelsText, "endList":False, "index": indexNumber, "length":len(allTweets), "outputList": showAnnotations}

            returner = HttpResponse(json.dumps(data), content_type="application/json")
            return returner










@csrf_exempt
def send_data(request):

    print("<>       request : "+str(request))

    output = str(request.POST.get('button', None))

    print("output : "+str(output))

    return HttpResponse(output, content_type="text/plain")



#list1 = Tweet.objects.all()
progress=1

def DisplayTweet(data):
    #user = request.user
    #if request.user == 'dav':
    progress=1
    tweet = Tweet.objects.get(pk=progress)

    return [tweet.Publisher, tweet.Text, tweet.uuid]



output = []

def fetch_tweets(request):
    return render(request, 'titanApp/fetch_tweets.html', {'title': 'about'}) #added

def ml_params(request):
    return render(request, 'titanApp/ml_params.html', {'title': 'about'}) #added

def IAA(request):
    return render(request, 'titanApp/IAA.html', {'title': 'about'}) #added



def home(request):
    print("HOME")
    global output

    print("----------------------------------------------------       request : "+str(request))

    if request.method == 'POST':

        data = request.POST

        if request.POST.get('function', None) == "LoadTweet":
            output = DisplayTweet(data)

    return render(request, 'titanApp/home.html', {'output': output})


def model_train(request):
    model = request.POST.get('model')
    output_dir = request.POST.get('output_dir')
    n_iter = int(request.POST.get('n_iter'))
    n_texts = int(request.POST.get('n_texts'))
    blank_lang = request.POST.get('blank_lang')
    multi_label = request.POST.get('multi_label')
    active_list = request.POST.get('active_list')
    threshold = float(request.POST.get('threshold'))
    split = float(request.POST.get('split'))

    if multi_label == 'False':
        multi_label = False
    else:
        mulit_label = True



    active_list = ListToAnnotate.objects.get(Name = active_list).id
    print(active_list)
    print(multi_label)
    
    loss, acc, recall, f1 = train_model(model = model, output_dir = output_dir, n_iter = n_iter, n_texts = n_texts, blank_lang = blank_lang, multi_label = multi_label, active_list = active_list, threshold = threshold, split = split)
    
    data = {'loss': loss, 'acc': acc, 'recall': recall, 'f1': f1}
    print(data)
    returner = HttpResponse(json.dumps(data), content_type="application/json")
    return returner


def train_model(model=None, output_dir='./mlmodels', n_iter=20, n_texts=None, blank_lang='en', multi_label=False, active_list = 5, threshold = 0.7, split = 0.7):



    if model == 'None':
        model = None
    #Save Model in output directory 
    if output_dir is not None:
        output_dir = Path(output_dir)
        if not output_dir.exists():
            output_dir.mkdir()

    #Load Spacy Language Model
    if model is not None:
        nlp = spacy.load(model)  # load existing spaCy model
        print("Loaded model '%s'" % model)
    else:
        nlp = spacy.blank(blank_lang)  # create blank Language class
        print("Created blank", blank_lang,  "model")

    #Add Spacy TextCat with multilabel respect
    if "textcat" not in nlp.pipe_names:    
        if multi_label == True:
            textcat = nlp.create_pipe(
                "textcat", config={"exclusive_classes": False, "architecture": "simple_cnn"}
            )        
        else:
            textcat = nlp.create_pipe(
                "textcat", config={"exclusive_classes": True, "architecture": "simple_cnn"}
            )
        nlp.add_pipe(textcat, last=True)
    else:
        textcat = nlp.get_pipe("textcat")

    #Get and Add Labels to TextCategorizer

    labels = AnnotationLabel.objects.filter(listtoannotate = active_list).values_list('LabelText', flat = True)
    for label in labels:
        textcat.add_label(label)


    #Get Training and Testing Data (text)
    (train_texts, train_cats), (dev_texts, dev_cats) = getData(multilabel = multi_label, threshold = threshold, active_list = active_list, split = split)

    #Clean Training & Test Data
    clean_train_texts = TextCleaner(train_texts, nlp.tokenizer)
    clean_dev_texts = TextCleaner(dev_texts, nlp.tokenizer)

    #Train off n_texts amount of texts and print info about data
    train_texts = clean_train_texts[:n_texts]
    train_cats = train_cats[:n_texts]
    print(
        "Using {} examples ({} training, {} evaluation)".format(
            n_texts, len(train_texts), len(dev_texts)
        )
    )
    train_data = list(zip(train_texts, [{"cats": cats} for cats in train_cats]))

    #train the single-label textcategorizer
    pipe_exceptions = ["textcat", "trf_wordpiecer", "trf_tok2vec"]
    other_pipes = [pipe for pipe in nlp.pipe_names if pipe not in pipe_exceptions]
    with nlp.disable_pipes(*other_pipes):  # only train textcat
        optimizer = nlp.begin_training()
        print("Training the model...")
        print("{:^5}\t{:^5}\t{:^5}\t{:^5}".format("LOSS", "Pr", "Re", "F"))
        batch_sizes = compounding(4.0, 32.0, 1.001)
        for i in range(n_iter):
            losses = {}
            # batch up the examples using spaCy's minibatch
            random.shuffle(train_data)
            batches = minibatch(train_data, size=batch_sizes)
            for batch in batches:
                texts, annotations = zip(*batch)
                nlp.update(texts, annotations, sgd=optimizer, drop=0.2, losses=losses)
            with textcat.model.use_params(optimizer.averages):
                # evaluate on the dev data split off in load_data()
                scores = evaluate(nlp.tokenizer, textcat, clean_dev_texts, dev_cats, multi_label, active_list)
            print(
                "{0:.3f}\t{1:.3f}\t{2:.3f}\t{3:.3f}".format(  # print a simple table
                    losses["textcat"],
                    scores["textcat_p"],
                    scores["textcat_r"],
                    scores["textcat_f"],
                )
            )


    #Save Model for re-use
    if output_dir is not None:
        with nlp.use_params(optimizer.averages):
            nlp.to_disk(output_dir)
        print("Saved model to", output_dir)

    return losses['textcat'], scores["textcat_p"], scores["textcat_r"], scores["textcat_f"]


def getData(multilabel = False, threshold = 0.7, active_list = 5, split = .8):

    users = AnnotatorUser.objects.filter(AvailableLists = active_list)
    tweets = Tweet.objects.filter(listtoannotate = active_list)
    labels = AnnotationLabel.objects.filter(listtoannotate = active_list).values_list('LabelText', flat = True)

    labels_dict = {}
    for i in labels:
        labels_dict[i] = []
    
    texts = []
    cats = []

    for tweet in tweets:
        
        tweet_text = tweet.Text
        valuelist_dict = {}
        for i in labels:
            valuelist_dict[i] = []
        for user in users:
            anno_bundles = AnnotationBundle.objects.filter(forList=active_list, Tweet=tweet, User=user)
            for bundle in anno_bundles:
                annotationpieces = bundle.AnnotationsList.values_list('Label', 'Input')
                _labels_dict = {}
                for i in labels:
                    _labels_dict[i] = None
                for label, bool_value in annotationpieces:
                    _labels_dict[label] = str(bool_value)
                
            for i in labels_dict:
                valuelist_dict[i].append(_labels_dict[i])

        for item in valuelist_dict.items():
            countvalues = Counter(item[1])
            if multilabel == False:
                if countvalues['True'] >= countvalues['False']:
                    labels_dict[item[0]] = True
                else:
                    labels_dict[item[0]] = False
            else:
                if countvalues['True'] == 0 and countvalues['False'] > 0:
                    labels_dict[item[0]] = False

                elif countvalues['False'] == 0 and countvalues['True'] > 0:
                    labels_dict[item[0]] = True
                        
                elif (countvalues['True'] / countvalues['False']) >= threshold:
                    labels_dict[item[0]] = True
                else:
                    labels_dict[item[0]] = False
        
        for label, value in labels_dict.items():
            label = label.lower()

        cats.append(labels_dict.copy())
        texts.append(tweet_text)

    split = float(split)

    split = int(len(texts) * split)

    return (texts[:split], cats[:split]), (texts[split:], cats[split:])


def predict(text, output_dir = '../mlmodels'):
    nlp = spacy.load(output_dir)
    clean_text = TextCleaner(text, nlp.tokenizer)
    doc = nlp(text)

    pred_labels = []
    for label, score in doc.cats.items():
        if score >= 0.5:
            pred_labels.append(label)

    return pred_labels


def predictor(request):
    text = str(request.POST.get('rememberText'))
    output_dir = str(request.POST.get('output_dir'))

    data = predict(text, output_dir = output_dir)

    data = {'Labels': data}

    returner = HttpResponse(json.dumps(data), content_type="application/json")
    return returner





def evaluate(tokenizer, textcat, texts, cats, multi_label, active_list):
    labels = AnnotationLabel.objects.filter(listtoannotate = active_list).values_list('LabelText', flat = True)
    docs = (tokenizer(text) for text in texts)
    tp = 0.0 
    fp = 0.0
    fn = 0.0
    tn = 0.0
    for i, doc in enumerate(textcat.pipe(docs)):
        gold = cats[i]
        check_dict = {}

        for i in labels:
            check_dict[i] = False

        threshold = 1 / len(labels)

        for label, score in doc.cats.items():
            if multi_label == False:
                #define borders depends on number of labels , for single-label take the highest as the only true!!!
                if score >= threshold and gold[label] == True:
                    tp += 1
                elif score >= threshold and gold[label] == False:
                    fp += 1
                elif score < threshold and gold[label] == False:
                    tn += 1
                elif score < threshold and gold[label] == True:
                    fn += 1
            else:
                if score >= 0.5 and gold[label] == True:
                    tp += 1
                elif score >= 0.5 and gold[label] == False:
                    fp += 1
                elif score < 0.5 and gold[label] == False:
                    tn += 1
                elif score < 0.5 and gold[label] == True:
                    fn += 1

    precision = tp / (tp + fp)
    recall = tp / (tp + fn)
    if (precision + recall) == 0:
        f_score = 0.0
    else:
        f_score = 2 * (precision * recall) / (precision + recall)
    return {"textcat_p": precision, "textcat_r": recall, "textcat_f": f_score}

def TextCleaner(text, tokenizer_model):
    if isinstance(text, list):
        lemmatized_text = []
        for i in text:            
            tokens = tokenizer_model(i)
            lemma_list = []
            for token in tokens:  
                if not (token.is_punct):
                    if not (token.is_stop):
                        if not (token.like_url):
                            if not (token.text.startswith('@')):
                                lemma_list.append(token.lemma_.lower())

            converttostr = ' '.join(lemma_list)
            lemmatized_text.append(converttostr)
    elif isinstance(text, str):
        tokens = tokenizer_model(text)
        lemma_list  = []
        for token in tokens:
            if not (token.is_punct):
                if not (token.is_stop):
                    lemma_list.append(token.lemma_)
        lemmatized_text = ' '.join(lemma_list)
    else:
        raise TypeError

    return lemmatized_text





def collect_tweets(users_in, pr=None, oldest=None, amount_per_user = None, max_amount=None):

    if oldest is not None:
        oldest = datetime.datetime.strptime(oldest, "%m/%d/%Y").replace(tzinfo=None)
    if type(users_in) is str:
        users_in = [users_in]
    api = twitter.Api(consumer_key=KEY,
                      consumer_secret=SECRET,
                      access_token_key=ACCESS_TOKEN,
                      access_token_secret=ACCESS_TOKEN_SECRET,
                      sleep_on_rate_limit=True,
                      tweet_mode="extended")
    for i, user in enumerate(users_in):
        
        if max_amount is not None:
            amount_per_user = max_amount // len(users_in)
        


        if pr is not None:
            pr.set_progress(i + 1, len(users_in), description = f'Collecting for user {user}')
        tweets = []
        prev = None
        tweetlist = []
        try:
            while True:
                if prev is None:
                    data = api.GetUserTimeline(screen_name=user, count = amount_per_user, exclude_replies= True, include_rts=True)
                else:
                    data = api.GetUserTimeline(screen_name=user, count = amount_per_user, include_rts=True, max_id=prev)
                prev = data[-1].id
                tweets.extend(data)
                if len(data) < 200:
                    break
        except twitter.TwitterError:
            pass
        tweets = [json.loads(x.AsJsonString()) for x in tweets]

        if amount_per_user is not None:
            tweets = tweets


        for tweet in tweets:
            print(tweet)
            tweet = defaultdict(lambda: None, tweet)
            try:
                created_at = datetime.datetime.strptime(tweet["created_at"], "%m/%d/%Y").replace(tzinfo=None)
                make_aware(created_at)
            except ValueError:
                created_at = datetime.datetime.strptime(tweet["created_at"], "%a %b %d %H:%M:%S %z %Y").replace(tzinfo=None)

            if oldest is not None:
                if created_at <= oldest:
                    pass


            tweet_obj = Tweet(
                Publisher = tweet['user']['screen_name'],
                Text = tweet['full_text'],
                URL = tweet['url'],
                created_at = created_at,
            )
            tweetlist.append(tweet_obj)

        existing = set(Tweet.objects.all().values_list('Text', flat = True))

        create = [x for x in tweetlist if x.Text not in existing]

        try:
            saved = 0
            for tweet in create:
                try:
                    tweet.save()
                    saved += 1
                except IntegrityError as e:
                    continue
                print(f'Saved {saved} (new) Tweets for user {user}.')
        except IntegrityError:
            print("Integ Error while saving, maybe exists?")



def tweetcollector(request):
    users_in = request.POST.get('users_in')
    oldest = str(request.POST.get('oldest'))
    amount_per_user = request.POST.get('amount_per_user')
    max_amount = request.POST.get('max_amount')

    users_in = users_in.split(',')

    if oldest == '':
        oldest = None

    if amount_per_user == '':
        amount_per_user = None
    else:
        amount_per_user = int(amount_per_user)

    if max_amount == '':
        max_amount = None
    else:
        max_amount = int(max_amount)

    collect_tweets(users_in = users_in, oldest = oldest, amount_per_user=amount_per_user, max_amount = max_amount)

    data = {'Success': 'Success!!!'}
    returner = HttpResponse(json.dumps(data), content_type="application/json")
    return returner



def remove_tweets(users):
    if type(users) is str:
        users = [users]
    for user in users:
        Tweet.objects.filter(Publisher = user).delete()
        print(f"Deleting tweets for user: {user}")    

def tweetremover(request):
    users = request.POST.get('users')
    users = users.split(',')

    remove_tweets(users = users)
    data = {'Success': 'Success!!!'}
    returner = HttpResponse(json.dumps(data), content_type="application/json")
    return returner


def cohen_kappa_table(forList, anonymous = True):
   
    forList = ListToAnnotate.objects.get(Name = forList).id
    
    userobjectlist = AnnotatorUser.objects.filter(AvailableLists = forList).values()   
    user_ids = [i['id'] for i in userobjectlist]
    usernames = [i['Name'] for i in userobjectlist]
    

    tweets = Tweet.objects.filter(listtoannotate = forList)

    labels = list(AnnotationLabel.objects.filter(listtoannotate = forList).values_list('LabelText', flat = True))

    if anonymous is not True:   
        IAA_df = pd.DataFrame(columns = usernames, index = usernames)
    else:
        IAA_df = pd.DataFrame(columns = user_ids, index = user_ids)

    for user1 in user_ids:
        
        user1_name = userobjectlist.get(id = user1)['Name']
        user2_list = user_ids[(user_ids.index(user1))+1:]

        cohen_list1 = []

        complist1 = AnnotationBundle.objects.filter(User = user1, forList = forList).values_list('Tweet_id') 

        for tweet in tweets:            
            annotation_objects1 = AnnotationBundle.objects.filter(User = user1, forList = forList, Tweet = tweet)
            for bundle in annotation_objects1:
                                
                annotation_bundles1 = bundle.AnnotationsList.values_list('Label', 'Input')
                for i in annotation_bundles1:

                    if i[1] == True:
                        cohen_list1.append(i[0])

        for user2 in user2_list:
            user2_name = userobjectlist.get(id = user2)['Name']

            cohen_list2 = []

            complist2 = AnnotationBundle.objects.filter(User = user2, forList = forList).values_list('Tweet_id')

            for tweet in tweets:
                annotation_objects2 = AnnotationBundle.objects.filter(User = user2, forList = forList, Tweet = tweet)

                for bundle in annotation_objects2:
                    annotation_bundles2 = bundle.AnnotationsList.values_list('Label', 'Input')

                    for i in annotation_bundles2:

                        if i[1] == True:
                            cohen_list2.append(i[0])

            for index, item in enumerate(complist1):
                if item not in complist2:
                    cohen_list1.remove(cohen_list1[index])

            for index, item in enumerate(complist2):
                if item not in complist1:
                    cohen_list2.remove(cohen_list2[index])

            cohen_kappa = cohen_kappa_score(cohen_list1, cohen_list2)

            if anonymous is True:
                IAA_df[user1][user2] = cohen_kappa
                IAA_df[user2][user1] = cohen_kappa
            else:
                IAA_df[user1_name][user2_name] = cohen_kappa
                IAA_df[user2_name][user1_name] = cohen_kappa

    return IAA_df.to_html()



def cohenmaker(request):
    forList = str(request.POST.get('forList'))
    anonymous = str(request.POST.get('anonymous'))

    if anonymous == 'True':
        anonymous = True
    elif anonymous == 'False':
        anonymous = False

    data = cohen_kappa_table(forList = forList, anonymous = anonymous)

    data = {'Table': data}
    returner = HttpResponse(json.dumps(data), content_type="application/json")
    return returner


def krippendorff_fleiss_score(forList):
    forList = ListToAnnotate.objects.get(Name = forList).id

    userobjectlist = AnnotatorUser.objects.filter(AvailableLists = forList).values()   
    user_ids = [i['id'] for i in userobjectlist]
    usernames = [i['Name'] for i in userobjectlist]
    
    tweets = Tweet.objects.filter(listtoannotate = forList)

    labels = list(AnnotationLabel.objects.filter(listtoannotate = forList).values_list('LabelText', flat = True))

    kripp_array = []
    helplist = []
    
    fleiss_array = []
    remove_list = []

    for index, item in enumerate(tweets):
        helplist.append(item.id)

    for user in user_ids:
        
        kripp_list = [0 for i in tweets]
        for tweet in tweets:
            annotation_objects = AnnotationBundle.objects.filter(User = user, forList = forList, Tweet = tweet)

            for bundle in annotation_objects:
                annotation_bundles = bundle.AnnotationsList.values_list('Label', 'Input')

                for i in annotation_bundles:

                    if i[1] == True:
                        kripp_list[helplist.index(tweet.id)] = i[0]

        for label in kripp_list:
            for i in labels:
                if label == i:
                    kripp_list[kripp_list.index(label)] = labels.index(i) + 1

        for i in kripp_list:
            if i == 0:
                remove_list.append(kripp_list.index(i))

        kripp_array.append(kripp_list)
        fleiss_array.append(kripp_list)

    krippendorff_score = krippendorff.alpha(np.array(kripp_array))

    remove_list.sort(reverse = True)
    for i in remove_list:
        for item in fleiss_array:
            item.remove(item[i])

    fleiss_final = []
    for i in fleiss_array:
        count = Counter(i)
        
        fleiss_final_element = [0 for i in range(len(label))]
        for index, key in enumerate(count):
            print(count[key])
            fleiss_final_element[key-1] = count[key]
        
        fleiss_final.append(fleiss_final_element)

    fleiss_score = fleiss_kappa(np.array(fleiss_final))

    return fleiss_score, krippendorff_score


def krippmaker(request):
    forList = str(request.POST.get('forList'))

    fleiss, kripp = krippendorff_fleiss_score(forList)

    data = {'fleiss': fleiss, 'kripp': kripp}

    returner = HttpResponse(json.dumps(data), content_type="application/json")
    return returner