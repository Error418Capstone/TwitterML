from django.contrib import admin

from .models import Tweet, ListToAnnotate, AnnotationBundle, AnnotatorUser, AnnotationLabel, AnnotationPiece, AnnotationProject, AnnotationAttempt

admin.site.register(Tweet)
admin.site.register(ListToAnnotate)
admin.site.register(AnnotationPiece)
admin.site.register(AnnotationBundle)
admin.site.register(AnnotatorUser)
admin.site.register(AnnotationLabel)
admin.site.register(AnnotationProject)
admin.site.register(AnnotationAttempt)
