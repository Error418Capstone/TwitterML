/*jslint browser: true*/
/*global $, jQuery, alert*/


//window.alert("anyway it works")



var indexNumber = 0;
var annotateName;
var user_name = document.getElementById('username').textContent;

var labelsList;


var savedProjects;

var rememberText;


function checkboxClick(index){
    if (labelsList[index] == 1){
        labelsList[index] = 0;
        console.log(labelsList[index]);
    }
    else {
        labelsList[index] = 1;
        console.log(labelsList[index]);
    }
    
    console.log(labelsList);
}



function listClick(title) {
    console.log(title);
    inputData =  {"title": title};
    console.log(inputData);
    
    $.ajax({
        url:'listClicked',
        type:'POST',
        data:inputData,
        dataType: "json",
        success: function(response) {
            console.log("passed title click");
            
            $('document').ready(function(){
                document.getElementById("titles").innerHTML = "";
                document.getElementById("pageTitle").innerHTML = "List : " + title;
                document.getElementById("pageInstructions").innerHTML = "Please annotate the following tweets : "; 
            });
            
            BeginList(user_name, title);
        }
    });   
}





function projectClick(title) {
    console.log(title);
    inputData =  {"title": title};
    console.log(inputData);
    
    $.ajax({
        url:'projectClicked',
        type:'POST',
        data:inputData,
        dataType: "json",
        success: function(response) {
            console.log("passed title click");
            
            $('document').ready(function(){
                document.getElementById("titles").innerHTML = "";
                savedProjects = title;
            });
            
            constructListMenu(title, user_name)
        }
    });   
}


function constructListMenu(titles, user){
    
    inputData =  {"user": user, "title": titles};
    console.log(inputData);
    
    indexNumber = 0;
    
    nextButton.style.display = 'none';
    previousButton.style.display = 'none';
    backToMenuButton.style.display = 'none';
    
    
    $.ajax({
        url:'getListsToAnnotate',
        type:'POST',
        data:inputData,
        dataType: "json",
        success: function(response) {
            
            projectTitle = response['projectTitle'];
            titles = response['listNames'];
            bundles = response['listBundles'];
            length = response['listLength'];
            users = response['outputList'];

            titlesList = [];
            outputSting = "";
            
            for (i = 0; i < titles.length; i++) {
                outputSting += '<b><a class="btn btn-light" onclick= "listClick('+"'"+titles[i]+"'"+')">'+ titles[i] + "  " + bundles[i] + "/" + (length[i]) +'</a></b> <br><br>';
            }
            
            $('document').ready(function(){
                document.getElementById("tags").innerHTML = "";    
                document.getElementById("titles").innerHTML = outputSting;
                document.getElementById("pageTitle").innerHTML = "Project : " + projectTitle; 
                document.getElementById("pageInstructions").innerHTML = "Please pick a list out of this project that you would like to annotate : "; 
            });
        }
    });
}



function constructMenu(){
    constructListMenu(savedProjects, user_name);
    document.getElementById("index").innerHTML = "";
}




function constructProjectMenu(){
    
    inputData =  {"user": user_name};
    console.log(inputData);
    
    indexNumber = 0;
    
    nextButton.style.display = 'none';
    previousButton.style.display = 'none';
    backToMenuButton.style.display = 'none';

    predict.style.display = 'none';
    
    $.ajax({
        url:'getProjects',
        type:'POST',
        data:inputData,
        dataType: "json",
        success: function(response) {
            
            titles = response['outputList'];

            titlesList = [];
            
            
            outputSting = "";
            
            for (i = 0; i < titles.length; i++) {
                outputSting += '<b><a class="btn btn-light" onclick= "projectClick('+"'"+titles[i]+"'"+')">'+ titles[i] +'</a></b> <br><br>';
            }
            
            $('document').ready(function(){
                
                document.getElementById("tags").innerHTML = "";
                document.getElementById("titles").innerHTML = outputSting;
                document.getElementById("pageTitle").innerHTML = "Available Projects"; 
                document.getElementById("pageInstructions").innerHTML = "Please pick a project you want to work on :"; 
                
            });
        }

    });
 
}

function train_model(){
    var model = document.getElementById("model").value;
    var output_dir = document.getElementById("output_dir").value;
    var n_iter = document.getElementById("n_iter").value;
    var n_texts = document.getElementById("n_texts").value;
    var blank_lang = document.getElementById("blank_lang").value;
    var active_list = document.getElementById("active_list").value;
    var threshold = document.getElementById("threshold").value;
    var split = document.getElementById("split").value;
    var multi_label = document.getElementById("multi_label").value;

    inputData =  {"model": model, "output_dir": output_dir, "n_iter": n_iter, "n_texts": n_texts, "blank_lang": blank_lang, "active_list": active_list, "threshold": threshold, "split": split, "multi_label":multi_label};

    console.log(inputData);

    $.ajax({
        url:'../model_train',
        type:'POST',
        data:inputData,
        dataType: "json",
        success: function(response) {
            
            console.log(inputData);

            document.getElementById('loss').innerHTML = response['loss'];
            document.getElementById('acc').innerHTML = response['acc'];
            document.getElementById('recall').innerHTML = response['recall'];
            document.getElementById('f1').innerHTML = response['f1'];
            


        }


    });   
}


function predictlabel(){
    var output_dir = document.getElementById('output_dir').value;
    console.log(rememberText);
    console.log(output_dir);

    inputData = {'text': rememberText, 'output_dir': output_dir};

    console.log(inputData);

    $.ajax({
        url:'predictor',
        type:'POST',
        data:inputData,
        dataType:'json',
        success: function(response) {
            console.log(inputData);
            document.getElementById('PredLabel').innerHTML = response['Labels'];
            
        }

    });
}



function cohen_kappa_table(){
    

    var forList = document.getElementById('forList').value;
    var anonymous = document.getElementById("anonymous").value;

    
    inputData =  {'forList': forList, 'anonymous': anonymous};
    
    console.log(inputData);
    
    $.ajax({
        url:'../cohenmaker',
        type:'POST',
        data:inputData,
        dataType: "json",
        success: function(response) {
            console.log(inputData);


            $('document').ready(function(){       
                document.getElementById('Cohen_Table').innerHTML = response['Table'];



            })


        }
            
    });
    
}


function krippendorff_fleiss_score(){
    
    var forList = document.getElementById('forList2').value;

    inputData =  {'forList': forList,};

    console.log(inputData);

    $.ajax({
        url:'../krippmaker',
        type:'POST',
        data:inputData,
        dataType: "json",
        success: function(response) {
            console.log(inputData);


            $('document').ready(function(){       
                document.getElementById('fleiss').innerHTML = response['fleiss'];
                document.getElementById('kripp').innerHTML = response['kripp'];



            })


        }
            
    });



}






function collect_tweets(){

        var users_in = document.getElementById("users_in").value;
        var oldest = document.getElementById('oldest').value;
        var amount_per_user = document.getElementById("amount_per_user").value;
        var max_amount = document.getElementById("max_amount").value;

        inputData =  {"users_in": users_in, 'oldest': oldest, "amount_per_user": amount_per_user, "max_amount": max_amount};
    
        console.log(inputData);
    
        $.ajax({
            url:'../tweetcollector',
            type:'POST',
            data:inputData,
            dataType: "json",
            success: function(response) {     
                document.getElementById("Success").innerHTML = response['Success'];
                


            
            }


        });
        
    }
   


function removeTweets(){
        
        var users = document.getElementById("users").value;


        inputData =  {"users": users};
    
        console.log(inputData);

        $.ajax({
            url:'../tweetremover',
            type:'POST',
            data:inputData,
            dataType: "json",
            success: function(response) {
                console.log(inputData);
                document.getElementById('Remove').innerHTML = response['Success'];
            }


        });
        
    }







function constructLabels(Labels, inputs){
    
    outputSting = "";
    
    console.log("constructLabels");
    console.log(inputs);
    
    labelsList = []
    
    for (a = 0; a < Labels.length; a++) {
        //console.log(Labels[a] + " : "+inputs[a]);
        if (inputs[a] == 1){
           outputSting += '<label for="Label1">'+Labels[a]+'</label> <input type="checkbox" id="'+Labels[a]+'" onclick="checkboxClick('+a+');" checked><br>'; 
            labelsList.push(1);
        }       
        else{
            outputSting += '<label for="Label1">'+Labels[a]+'</label> <input type="checkbox" id="'+Labels[a]+'" onclick="checkboxClick('+a+');"><br>';
            labelsList.push(0);
            }
    }
    
    return outputSting;
    
    
}




var nextButton = document.getElementById('nextButton');
var previousButton = document.getElementById('previousButton');
var backToMenuButton = document.getElementById('backToMenuButton');



function constructEndList(publishers, text, annotations, labels){
    
    fullHTML = '';
    
    console.log(labels);
    
    for (i = 0; i < publishers.length; i++) {
        
        if (i > 0){
            fullHTML += '<br>';
            fullHTML += '<br>';
            fullHTML += '<br>';
            fullHTML += '<br>';
            
        }
        fullHTML += 'Publisher : ' + publishers[i];
        fullHTML += '<br>';
        fullHTML += '<br>';
        fullHTML += 'Text : ' + text[i];
        fullHTML += '<br>';
        fullHTML += '<br>';
        constructed = constructLabels(labels, annotations[i]);
        fullHTML += '<span id=labels'+i+'>'+constructed+"</span>";    
        document.getElementById("tags").innerHTML = fullHTML;
        
        //window.alert(i + "/"+publishers.length);
    }
    
    //document.getElementById("publisher").innerHTML = fullHTML;
}

function nextInList(action) {
    console.log(labelsList);
    console.log(user_name);
    
    
    labelsGiven = labelsList;
    inputData =  {"index": indexNumber, "annotateName": annotateName, labelsList: String(labelsGiven), "user": user_name, "action": action};
    
    console.log(inputData);
    
    $.ajax({
        url:'annotate_list',
        type:'POST',
        data:inputData,
        dataType: "json",
        success: function(response) {
            
            publisher = response['Publisher'];
            
            text = response['Text'];

            labels = response['Labels'];
            
            inputs = response['outputList'];
            
            indexNumber = response['index'];
            
            console.log(labelsList);
            console.log(inputs);
            
            labelsList = [];
            
            for (i = 0; i < labels.length; i++) {
                labelsList.push(0);
            }
                
            $('document').ready(function(){
                
                if(response['endList'] == true){
                    
                    console.log("response['endList'] == true")
                    
                    constructEndList(response['TweetsPublishers'], response['TweetsTexts'], response['TweetsAnnotations'], labels);
                    
                    nextButton.style.display = '';
                    previousButton.style.display = '';
                    backToMenuButton.style.display = 'inline';
                    
                    document.getElementById("publisher").innerHTML = "";
                    document.getElementById("text").innerHTML = "";
                    
                    document.getElementById("nextButton").style.visibility='hidden';
                    document.getElementById("previousButton").style.visibility='hidden'; 
                } 
                else if (response['endList'] == false){
                    output = constructLabels(labels, inputs);
                    
                    console.log(output);
                    document.getElementById('tags').innerHTML = output;
                    
                    console.log("response['endList'] == false")
                    backToMenuButton.style.display = 'none';
                    
                    document.getElementById("publisher").innerHTML = "Publisher : " + publisher;
                    document.getElementById("text").innerHTML = "Tweet : " + text; 

                    document.getElementById("index").innerHTML = (response['index'] +1 )+"/"+(response['length']);
                }
            });
            
            //$('#content').load(document.URL + ' #content');
        
        }

    });
}









function BeginList(User, ListToAnnotate) {
    //window.alert(ListToAnnotate);
    inputData = {"function": "LoadTweet", "user":User, "listToAnnotate":ListToAnnotate};
    
    annotateName = ListToAnnotate;
            
    nextButton.style.display = 'inline';
    previousButton.style.display = 'inline';

    predict.style.display = 'inline';

    
    console.log(annotateName);
    $.ajax({
        url:'begin_list',
        type:'POST',
        data:inputData,
        success: function(response) {
            

            publisher = response['Publisher'];
            text = response['Text'];
            labels = response['Labels'];
            
            rememberText = text;

            inputs = response['outputList'];
            
            indexNumber = response['index'];
            
            labelsList = [];
            
            for (i = 0; i < labels.length; i++) {
                labelsList.push(0);
            }
        
            output = constructLabels(labels, inputs);
                    
            console.log(output);
            document.getElementById('tags').innerHTML = output;
            
            
            document.getElementById("publisher").innerHTML = "Publisher : " + publisher;

            document.getElementById("text").innerHTML = "Tweet : " + text;
            
            document.getElementById("index").innerHTML = (response['index'] + 1)+"/"+(response['length']);

            document.getElementById("nextButton").style.visibility='visible';
            document.getElementById("previousButton").style.visibility='visible'; 
        }

    });
    
}


