#!/usr/local/bin/python3
from django.db import models
from django.contrib.auth.models import User
import uuid



class Tweet(models.Model):
    Publisher = models.CharField(max_length=200, null=True)
    Text = models.CharField(max_length=300, null=True)
    URL = models.CharField(max_length=200, null=True)
    created_at = models.CharField(max_length=200, null=True)

    def __str__(self):
        return "['"+str(self.Publisher)+"', '"+str(self.Text)+"', '"+str(self.URL)+"'],"



class AnnotationLabel(models.Model):
    LabelText = models.CharField(max_length=400, null=True)

    def __str__(self):
        return " ['"+str(self.LabelText)+"'],"

class ListToAnnotate(models.Model):
    Name = models.CharField(max_length=200)
    Labels = models.ManyToManyField(AnnotationLabel, null=True)
    Instructions = models.CharField(max_length=700, null=True)
    ContainsTweets = models.ManyToManyField(Tweet, null=True)


    def getContent(self):
        return self.ContainsTweets

    def __str__(self):
        return str(self.Name)












class AnnotationPiece(models.Model):
    Label = models.CharField(max_length=400, blank=True)
    Input = models.BooleanField()

    def __str__(self):
        return str(self.Label) + " - " + str(self.Input)




class AnnotationProject(models.Model):
    Name = models.CharField(max_length=200, null=True)
    ContainsListsToAnnotate = models.ManyToManyField(ListToAnnotate, null=True)

    def __str__(self):
        return str(self.Name)



class AnnotatorUser(models.Model):
    Name = models.CharField(max_length=200, null=True)

    AvailableProjects = models.ManyToManyField(AnnotationProject, null=True)
    AvailableLists = models.ManyToManyField(ListToAnnotate, null=True)

    def __str__(self):
        return str(self.Name)



class AnnotationBundle(models.Model):
    Tweet = models.ForeignKey(Tweet, null=True, on_delete=models.SET_NULL)
    AnnotationsList = models.ManyToManyField(AnnotationPiece, null=True)
    User = models.ForeignKey(AnnotatorUser, null=True, on_delete=models.SET_NULL)
    forList = models.ForeignKey(ListToAnnotate, null=True, on_delete=models.SET_NULL)

    #AnnotatedByUser = models.ForeignKey(AnnotatorUser,  null=True, on_delete=models.SET_NULL)

    def __str__(self):
        return str(str(self.Tweet) + " -- "+str(self.AnnotationsList) + " -- "+str(self.User))




class AnnotationAttempt(models.Model):
    AnnotationList = models.ForeignKey(ListToAnnotate, null=True, on_delete=models.SET_NULL)
    ContainsAnnotationBundles = models.ManyToManyField(AnnotationBundle, null=True)
    User = models.ForeignKey(AnnotatorUser, null=True, on_delete=models.SET_NULL)


    def __str__(self):
        return str(str(self.AnnotationList) + " -- " + str(self.User))
