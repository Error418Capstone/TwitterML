# views.py
from django.conf import settings
from django.contrib import messages
from django.core.mail import send_mail
from django.shortcuts import render, redirect
from .forms import RegisterForm
from titanApp.models import AnnotatorUser




# Create your views here.
def register(response):
    if response.method == "POST":
        form = RegisterForm(response.POST)
        if form.is_valid():
            user = form.save()

        firstname = str(response.POST.get('first_name'))
        lastname = str(response.POST.get('last_name'))

        

        username = str(response.POST.get('username'))

        print("REGISTER: response.POST" + str(response.POST))
        print(username)

        create_user_object = AnnotatorUser(Name=username)
        create_user_object.save()
        

        return redirect("/")
    
    else:
        form = RegisterForm()

    return render(response, "register/register.html", {"form":form})



# sending data over in JSON -> to extract: define (chat)

# put username in 